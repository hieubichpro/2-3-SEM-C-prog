#ifndef _ADD_H_

#define _ADD_H_

inline int add(int a, int b)
{
    return a + b;
}

#endif