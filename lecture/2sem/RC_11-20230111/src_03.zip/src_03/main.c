#include "hello.h"
#include "bye.h"

int main(void)
{
	hello();

	goodbye();

	return  0;
}