#ifndef _FUNC_1_H_

#define _FUNC_1_H_

void f_1(void);

#endif