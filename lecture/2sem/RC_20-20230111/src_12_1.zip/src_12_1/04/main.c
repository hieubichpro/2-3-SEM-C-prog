#include "func_1.h"
#include "func_2.h"

int main(void)
{
    f_1();

    f_2();
}