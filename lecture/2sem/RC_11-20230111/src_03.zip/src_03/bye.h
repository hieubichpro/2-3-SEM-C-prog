#ifndef __BYE__H__

#define __BYE__H__


void goodbye(void);


#endif	// __BYE__H__