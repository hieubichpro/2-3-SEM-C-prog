#include <stdio.h>
#include "bye.h"

void goodbye(void)
{
    printf("See you!\n");
}