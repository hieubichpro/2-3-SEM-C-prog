#include <stdio.h>

#define STR(x) #x

#define NAME Bob

int main(void)
{
    puts(STR(10));

    puts(STR(NAME));

    return 0;
}
