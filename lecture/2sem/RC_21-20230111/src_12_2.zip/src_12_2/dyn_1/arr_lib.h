#ifndef __ARR__LIB__H__

#define __ARR__LIB__H__

__declspec(dllexport) void __cdecl arr_form(int *arr, int n);

__declspec(dllexport) void __cdecl arr_print(const int *arr, int n);

#endif  // __ARR__LIB__H__
