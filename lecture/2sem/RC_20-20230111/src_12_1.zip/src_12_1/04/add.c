#include "add.h"

extern inline int add(int a, int b);