#ifndef _FUNC_2_H_

#define _FUNC_2_H_

void f_2(void);

#endif