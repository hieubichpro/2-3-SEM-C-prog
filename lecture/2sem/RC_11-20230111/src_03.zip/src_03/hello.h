#ifndef __HELLO__H__

#define __HELLO__H__


void hello(void);


#endif	// __HELLO__H__
